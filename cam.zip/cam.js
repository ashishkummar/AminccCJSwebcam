(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib.MySym = function() {
	this.initialize(img.MySym);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,277,276);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.cammc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AB+BkQgigjAAg/QAAhBAigjQAhglA5AAQAwAAAeAdQASAQAKAfIg2AOQgEgVgPgMQgOgMgWAAQgeAAgRAVQgTAWAAAvQAAAxARAVQATAVAdAAQAVAAAQgNQAPgOAGgdIA0ARQgMAqgbAWQgdAUgqAAQg1ABghglgANHCEIAAjPIg0DPIgzAAIg1jPIAADPIgyAAIAAkHIBQAAIAwCzIAvizIBQAAIAAEHgAIkCEIgYg8IhpAAIgWA8Ig4AAIBnkHIA4AAIBqEHgAGzAcIBJAAIglhigAkLCEIAAkHIBqAAQAfAAAQADQAQABALAKQANAIAIANQAIAOAAASQAAASgKAPQgLARgRAHQAZAHANAPQANASAAAWQAAATgIARQgJARgOAKQgOAKgWABQgNADg0AAgAjWBZIAzAAQAcAAAIgDQAMgCAHgJQAHgHAAgPQAAgMgFgIQgGgJgKgEQgMgCgkAAIgsAAgAjWgaIAkAAIAmAAQAPgDAHgHQAIgJAAgMQAAgMgHgIQgHgIgNgBQgIgBgmgBIgfAAgAoBCEIAAkHIDEAAIAAAtIiOAAIAAA7ICFAAIAAAqIiFAAIAABKICTAAIAAArgAqUCEIg1jEIg1DEIg5AAIhAkHIA3AAIAoC0IAwi0IA/AAIAwC3IAni3IA2AAIhAEHg");
	this.shape.setTransform(309.1,241.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("Egx/AlgMAAAhK/MBj/AAAMAAABK/gAg+mnIAAiVIgCAAg");
	this.shape_1.setTransform(320,240);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cammc, new cjs.Rectangle(0,0,640,480), null);


// stage content:
(lib.cam = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var targetMC = this.box;
		
		var _cjBitmap;
		var _camWidth  =  targetMC.nominalBounds.width;
		var	_camHeight =  targetMC.nominalBounds.height;
		var _morror=true;
		
		
		navigator.getUserMedia = navigator.getUserMedia ||
			navigator.webkitGetUserMedia ||
			navigator.mozGetUserMedia ||
			navigator.msGetUserMedia;
		
		if (!navigator.getUserMedia) {
			return false;
		}
		 
		
		var video = document.createElement('video'), track;
			video.setAttribute('autoplay', true);
		 
			   
		
			navigator.getUserMedia({
				video: true,
				audio: false
			}, function (stream) {
				video.src = window.URL.createObjectURL(stream);
				track = stream.getTracks()[0];
			}, function (e) {
				console.error('Rejected!', e);
			});
		
		var  loopFrame; 
			 
		function loop() {
			
			loopFrame = requestAnimationFrame(loop); 
		 
			_cjBitmap = new createjs.Bitmap(video);
			
			 if(_morror){
		 	   _cjBitmap.scaleX = -1;
		 	   _cjBitmap.x = _camWidth;
			 }
		
			if (targetMC.numChildren >= 4) {
				for (var t = 0; t < targetMC.numChildren; t++) {
					targetMC.removeChildAt(t);
				}
			} 
		 
			 targetMC.addChild(_cjBitmap);
		 
		}
		
		
		function startLoop() {
			loopFrame = loopFrame || requestAnimationFrame(loop);
		}
		
		
		video.addEventListener('loadedmetadata', function () {
			startLoop();
		});
		
		//
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1,1,1).p("A4SyxMAwlAAAMAAAAljMgwlAAAg");
	this.shape.setTransform(251.4,171.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#333333").ss(1,1,1).p("Egq9gfPMBV7AAAMAAAA+fMhV7AAAg");
	this.shape_1.setTransform(275,200);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.box = new lib.cammc();
	this.box.parent = this;
	this.box.setTransform(106,62.2,0.455,0.455,0,0,0,0.1,0.4);

	this.timeline.addTween(cjs.Tween.get(this.box).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(274,199,552,402);
// library properties:
lib.properties = {
	width: 550,
	height: 400,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/MySym.jpg?1490020947023", id:"MySym"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;